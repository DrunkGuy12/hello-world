javascript:(function(){
 var s=document.createElement('script');
 s.src='https://127.0.0.1:2838/tw2overflow.js?'+Date.now();
 document.getElementsByTagName('head')[0].appendChild(s)
})()
