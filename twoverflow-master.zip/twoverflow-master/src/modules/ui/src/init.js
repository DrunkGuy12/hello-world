require([
    'two/ui'
], function (
    interfaceOverflow
) {
    interfaceOverflow.addStyle('__interface_css_style')
})
