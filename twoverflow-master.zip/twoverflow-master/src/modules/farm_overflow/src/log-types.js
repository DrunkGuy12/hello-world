define('two/farmOverflow/logTypes', [], function () {
    return {
        ATTACK: 'attack',
        VILLAGE_SWITCH: 'village_switch',
        NO_PRESET: 'no_preset',
        PRIORITY_TARGET: 'priority_target',
        IGNORED_VILLAGE: 'ignored_village'
    }
})
