define('two/commandQueue/dateTypes', [], function () {
    return {
        ARRIVE: 'date_type_arrive',
        OUT: 'date_type_out'
    }
})
