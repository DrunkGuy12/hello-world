define('two/commandQueue/storageKeys', [], function () {
    return {
        QUEUE_COMMANDS: 'command_queue_commands',
        QUEUE_SENT: 'command_queue_sent',
        QUEUE_EXPIRED: 'command_queue_expired',
        LAST_DATE_TYPE: 'command_queue_last_date_type'
    }
})
