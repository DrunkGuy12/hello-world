define('two/attackView/filterTypes', [], function () {
    return {
        'COMMAND_TYPES' : 'command_types',
        'VILLAGE' : 'village',
        'INCOMING_UNITS' : 'incoming_units'
    }
})
